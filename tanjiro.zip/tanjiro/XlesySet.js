// config.js
const XlesySet = {
    // Info
    owner: ['6288980152187'],
    packname: '𝚃𝚊𝚗𝚓𝚒𝚛𝚘 v1',
    author: 'ƑƦȤ',
    botname: '𝑇𝑎𝑛𝑗𝑖𝑟𝑜',
    listprefix: ['.'],
    listv: ['〆','〆','々','々'],
    number_bot: "", // Kalo pake panel bisa masukin nomor di sini, jika belum ambil session. Format: '628xx'
    // Payment
    dana: [''],
    gopay: [''],
    ovo: ['kosong'],
    qris: ['kosong'],
};

module.exports = XlesySet
